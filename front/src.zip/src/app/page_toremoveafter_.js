'use client'

import Image from 'next/image'
import { ApolloClient, InMemoryCache, gql } from '@apollo/client'
import { initializeApollo } from '../../lib/apolloClient'
import { Box, Button, Dialog, DialogContent, DialogTitle, Grid, Stack, Typography } from '@mui/material'
import { useState } from 'react'

export default function Home({articles}) {

  const [isOpen, setIsOpen] = useState(false);
  console.log('isOpen :');
  console.log(isOpen);
  console.log('article :');
  console.log(articles);

  return <Box sx={{display: 'flex', flexDirection: 'column'}}>
    <Typography variant='h4' sx={{display: 'flex', justifyContent: 'center', alignItems: 'center'}}>  
      圓你の法國留學夢<br />
      找留法學姊Cynthia
    </Typography>
    <Grid container columns={2} sx={{display: 'flex', justifyContent: 'space-between', paddingTop: '30px'}} direction={'row'}>
      <Grid xs={6} container direction='column' sx={{display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
      <Stack spacing={3} direction='column' sx={{textAlign: 'center'}}>
        <Typography>
          你想到法國留學但不曉得如何開始?<br />
          你擔心隻身到法國留學會遇到問題?
        </Typography>
        <Stack  sx={{color: '#D896F6'}}>
          <Typography fontSize={28}>Cynthiaの留法筆記</Typography>
          <Typography fontSize={24}>一個月就完成法國留學那些事</Typography>
          <Typography fontSize={20}>(早鳥優惠中)</Typography>
        </Stack>
        <Typography>
        幫助你解決法國留學那些繁複程序<br />
        讓你可以無後顧之憂專注在學業上
        </Typography>
        <Button  sx={{border: "2px solid #D896F6", borderRadius: '20px', hover: {backgroundColor: 'red'}}} onClick={() => setIsOpen((prev) => !prev)}>
        <Typography sx={{color: 'black'}}>
          領取你的<br />
          法國留學申請流程懶人包
        </Typography>
        </Button>
        {isOpen && <Dialog open={isOpen} onClose={() => setIsOpen(false)} sx={{display: 'flex', justifyContent: 'center',  textAlign: 'center', alignItems: 'center', flexDirection: 'column'}}><DialogTitle></DialogTitle>TITLE<DialogContent>CONTENT</DialogContent></Dialog>}
      </Stack>
      </Grid>
      <Grid xs={6} container direction='column' sx={{display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
        <Stack spacing={3} direction='column' sx={{textAlign: 'center'}}>
          <Typography fontSize={24} color={'#D896F6'}>
          留法5年學姊Cynthia
          </Typography>
          <Typography>
          成功從法國及臺灣<br />
          申請多間法國學校
          </Typography>
        </Stack>
      </Grid>
    </Grid>
    </Box>
}

const HOME_QUERY = gql`
query HOME_QUERY {
  articles {
    data {
      id,
      attributes {
        title, 
        description
      }
    }
  }
}
`
/* 
const StyledButton = withStyles({
  root: {
    backgroundColor: '#3c52b2',
    color: '#fff',
    '&:hover': {
      backgroundColor: '#3c52b2',
      color: 'black',
  },
}})(Button);
*/

export async function getStaticProps() {
  //const apolloClient = initializeApollo()

  console.log('in getStaticProps');
  /*
  const client = new ApolloClient({
    uri: 'http://localhost:1337/graphql',
    cache: new InMemoryCache()
  })
  */

  const res = await fetch(`http://localhost:1337/articles`);
  const articles = await res.json();
  /* 
  const { data } = await client.query({
    query: HOME_QUERY
  });
  */

  //const pageResponse = await apolloClient.query({ query: HOME_QUERY })
  console.log('data :');
  console.log(data);
  return {
    props: {
      toto: 'test',
      //articles: data.articles,
      articles: articles
    }
  }
}
