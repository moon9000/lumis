'use client'

import Image from 'next/image'
import { ApolloClient, InMemoryCache, gql } from '@apollo/client'
import { Button } from '@mui/material'

export default function Articles({articles, toto}) {

  console.log('article :');
  console.log(articles);

  console.log('toto :');
  console.log(toto);

  return <div>TEST DU CONTENU 2 DE LA PAGE ARTICLES<Button>Test</Button></div>
}

const HOME_QUERY = gql`
query HOME_QUERY {
  articles {
    data {
      id,
      attributes {
        title, 
        description
      }
    }
  }
}
`

export async function getStaticProps() {
  //const apolloClient = initializeApollo()

  console.log('in getStaticProps');
  const client = new ApolloClient({
    uri: 'http://127.0.0.1:1337/graphql',
    cache: new InMemoryCache()
  })

  const { data } = await client.query({
    query: HOME_QUERY
  });

  //const pageResponse = await apolloClient.query({ query: HOME_QUERY })
  console.log('data :');
  console.log(data);
  const pageData = data
  console.log('pageData :');
  console.log(pageData);
  return {
    props: {
      toto: 'test',
      articles: pageData,
    }
  }
}
